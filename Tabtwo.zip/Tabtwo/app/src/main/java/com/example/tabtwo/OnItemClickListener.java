package com.example.tabtwo;

import com.example.tabtwo.GalleryAdapter;

public interface OnItemClickListener {

    void OnItemClick(GalleryAdapter.PhotoViewHolder photoViewHolder , int position);
}
